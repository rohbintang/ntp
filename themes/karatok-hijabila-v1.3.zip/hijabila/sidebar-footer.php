<div id="sidebar-footer" class="sidebar-footer clearfix" role="complementary">

	<?php if ( is_active_sidebar( 'sidebar-footer' ) ) : ?>

		<?php dynamic_sidebar( 'sidebar-footer' ); ?>

	<?php else : ?>

		<?php // This content shows up if there are no widgets defined in the backend. ?>

		<div class="alert alert-help">
			<p><?php _e( 'Please activate some Widgets.', 'hijabila' );  ?></p>
		</div>

	<?php endif; ?>

</div>
