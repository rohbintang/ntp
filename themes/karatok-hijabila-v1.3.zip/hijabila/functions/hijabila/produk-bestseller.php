<?php
function karatok_produk_bestseller() {
	global $karatok;
	$args = array(  'posts_per_page'  => $karatok['jumlahproduktabs'],
					'meta_key'     => 'karatok_label',
					'meta_value'   => 'Bestseller',
					'post_type'    => 'post',
					'post_status'  => 'publish',
				);
	$query = new WP_Query( $args );
	if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
		<?php get_template_part( 'entry', 'content' ); ?>
	<?php endwhile; ?>
	<?php else : ?>
		<div class="alert alert-info"><p>Tidak ada produk bestseller.</p></div>
	<?php endif; wp_reset_query();?>
<?php } ?>
