<?php
function karatok_pernah_dilihat() {
	global $karatok;
	?>
	<?php if( $karatok['pernahdilihat'] ) : ?>
		<section class="pernah-dilihat df cf">
			<h5 class="judul-pernah-dilihat">Pernah Dilihat</h5>
				<?php
					global $sj_seen;
					$categories = get_the_category();
					$cat_id = $categories[0]->term_id;

					$args = array(
						//'cat' => $cat_id,
						'post__in' => explode( ',', $sj_seen ),
						'post__not_in' => array($post->ID),
						'posts_per_page'=> 10
					);

					echo '<div id="pernahdilihat">';
					$my_query = new wp_query( $args );

					if ( $my_query->have_posts() ) : while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

						<?php get_template_part( 'entry', 'content' ); ?>

					<?php endwhile;
					echo '</div>';
					endif;

					wp_reset_query();
				?>

		</section>
	<?php endif; ?>
<?php } ?>
