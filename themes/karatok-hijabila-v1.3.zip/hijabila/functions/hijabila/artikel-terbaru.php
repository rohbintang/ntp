<?php
function karatok_artikel_terbaru() {
	global $karatok, $paged;
	if( $karatok['artikelon'] && $paged < 2 ) : ?>
	<div id="artikel-home" class="artikel-home mf tlf tf df cf">
		<?php if( $karatok['artikeltitle'] ) : ?>
		<h3 class="h4 judul-artikel-home"><?php echo $karatok['artikeltitle']; ?></h3>
		<?php endif; ?>

		<div id="bloghome-box" class="cf">
			<?php $mlq = new WP_Query(
						array(
							'post_type' => 'custom_type',
							'posts_per_page' => $karatok['jumlahartikel']
						)
					);
			if( $mlq->have_posts() ) : while($mlq->have_posts()) : $mlq->the_post(); ?>
			<article <?php post_class( 'blog-home m6 tl4 t4 d4 cf' ); ?> role="article">
					<div class="blog-home-entry">
						<span class="blog-home-kategori"><?php echo get_the_term_list( $post->ID, 'custom_cat', ' ', ', ', '' ) ?></span>
						<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<div class="thumb-blog-home">
								<?php the_post_thumbnail('large'); ?>
							</div>
							<h3 class="h5 judul-blog-home"><?php the_title(); ?></h3>
						</a>
						<?php //the_excerpt(); ?>
					</div>
			</article>
			<?php endwhile; ?>
			<?php else : ?>
				<div class="alert alert-help"><p>Tidak ada artikel untuk ditampilkan.</p></div>
			<?php endif; wp_reset_query(); ?>
		</div>
	</div>
	<?php endif; ?>
<?php } ?>
