<?php
function karatok_author() { ?>
	<section id="the-author" class="the-author twelvecol first clearfix">
		<div class="entry-head twelvecol first clearfix">
			<h4 class="h5 author-name"><?php the_author_link(); ?></h4>
		</div>
		<div class="author-post twelvecol first clearfix">
			<div class="author-avatar twocol first">
				<?php echo get_avatar( get_the_author_email(), '80'); ?>
			</div>

			<div class="author-description-box tencol last clearfix">
				<div class="author-description">
					<?php echo get_the_author_meta('description'); ?>
				</div>

				<div class="author-social">
					<ul>
						<?php

							// Personal Blog
							$personal_blog_url = get_the_author_meta( 'personal_blog_url' );
							if ( $personal_blog_url && $personal_blog_url != '' ) {
								echo '<li class="sj-home"><a href="' . esc_url($personal_blog_url) . '" rel="author"><i class="fa fa-home"></i></a></li>';
							}
							// RSS
							$rss_url = get_the_author_meta( 'rss_url' );
							if ( $rss_url && $rss_url != '' ) {
								echo '<li class="sj-rss"><a href="' . esc_url($rss_url) . '"><i class="fa fa-rss"></i></a></li>';
							}
							// Google Plus
							$google_profile = get_the_author_meta( 'google_profile' );
							if ( $google_profile && $google_profile != '' ) {
								echo '<li class="sj-googleplus"><a href="' . esc_url($google_profile) . '" rel="author"><i class="fa fa-google-plus"></i></a></li>';
							}
							// Twitter
							$twitter_profile = get_the_author_meta( 'twitter_profile' );
							if ( $twitter_profile && $twitter_profile != '' ) {
								echo '<li class="sj-twitter"><a href="' . esc_url($twitter_profile) . '"><i class="fa fa-twitter"></i></a></li>';
							}
							// Facebook
							$facebook_profile = get_the_author_meta( 'facebook_profile' );
							if ( $facebook_profile && $facebook_profile != '' ) {
								echo '<li class="sj-facebook"><a href="' . esc_url($facebook_profile) . '"><i class="fa fa-facebook"></i></a></li>';
							}
							// Linkedin
							$linkedin_profile = get_the_author_meta( 'linkedin_profile' );
							if ( $linkedin_profile && $linkedin_profile != '' ) {
								   echo '<li class="sj-linkedin"><a href="' . esc_url($linkedin_profile) . '"><i class="fa fa-linkedin"></i></a></li>';
							}
							// Dribbble
							$dribbble_profile = get_the_author_meta( 'dribbble_profile' );
							if ( $dribbble_profile && $dribbble_profile != '' ) {
								   echo '<li class="sj-dribbble"><a href="' . esc_url($dribbble_profile) . '"><i class="fa fa-dribbble"></i></a></li>';
							}
							// Instagram
							$instagram_profile = get_the_author_meta( 'instagram_profile' );
							if ( $instagram_profile && $instagram_profile != '' ) {
								echo '<li class="sj-instagram"><a href="' . esc_url($instagram_profile) . '"><i class="fa fa-instagram"></i></a></li>';
							}
							// Pinterest
							$pinterest_profile = get_the_author_meta( 'pinterest_profile' );
							if ( $pinterest_profile && $pinterest_profile != '' ) {
								echo '<li class="sj-pinterest"><a href="' . esc_url($pinterest_profile) . '"><i class="fa fa-pinterest"></i></a></li>';
							}
							// Youtube
							$youtube_url = get_the_author_meta( 'youtube_url' );
							if ( $youtube_url && $youtube_url != '' ) {
								echo '<li class="sj-youtube"><a href="' . esc_url($youtube_url) . '"><i class="fa fa-youtube"></i></a></li>';
							}
							//Flickr
							$flickr_profile = get_the_author_meta( 'flickr_profile' );
							if ( $flickr_profile && $flickr_profile != '' ) {
								echo '<li class="sj-flickr"><a href="' . esc_url($flickr_profile) . '"><i class="fa fa-flickr"></i></a></li>';
							}

						?>
					</ul>
				</div>
			</div>

		</div>
	</section>
<?php } ?>
