<?php
function karatok_home_slider_carousel() {
	global $karatok, $paged;
	if( $karatok['slideron'] && is_home() && $paged < 2 ) : ?>
	<div id="homesliderbox" class="mf tlf tf df fc cf">
		<?php if( !is_array( $karatok['homeslides'] ) || !$karatok['homeslides'][0]['attachment_id'] ) : ?><div class="alert alert-help"><p>Silakan tambahkan slides di theme option</p></div><?php endif; ?>
		<div id="homeslider" class="owl-carousel owl-theme">
		<?php foreach( $karatok['homeslides'] as $slide ) : ?>
			<?php if( $slide['attachment_id'] ) : ?>
			<div class="item">
				<?php if( $slide['url'] ) : ?><a href="<?php echo $slide['url']; ?>"><?php endif; ?>
				<img src="<?php echo $slide['image']; ?>" alt="<?php echo $slide['title']; ?>">
				<?php if( $slide['url'] ) : ?></a><?php endif; ?>
				<div class="slide-detail">
					<?php if( $slide['title'] ) : ?><h2 class="slide-title"><?php echo $slide['title']; ?></h2><?php endif; ?>
					<?php if( $slide['description'] ) : ?><p class="slide-description"><?php echo $slide['description']; ?></p><?php endif; ?>
				</div>
			</div>
			<?php endif; ?>
		<?php endforeach; ?>
		</div>
	</div>
	<?php endif; ?>

	<?php if( $karatok['carouselon'] && is_home() && $paged < 2 ) : ?>
	<div class="homecarouselbox mf tlf tf df fc cf">
		<h3 class="h4 judul-carouselhome"><?php echo $karatok['carouseltitle']; ?></h3>
		<div class="homecarousel-pagination homecarousel1">
			<span class="prev"><i class="fa fa-angle-left"></i></span>
			<span class="next"><i class="fa fa-angle-right"></i></span>
		</div>
		<div id="homecarousel1" class="owl-carousel owl-theme">
			<?php $args = array(
							'posts_per_page'  => $karatok['jumlahcarousel'],
							'post_type'    => 'post',
							'post_status'  => 'publish',
							'cat' => $karatok['carouselcat']
						);
			$query = new WP_Query( $args );
			if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
				<?php get_template_part( 'entry', 'content' ); ?>
			<?php endwhile; endif; wp_reset_query();?>
		</div>
	</div>
	<?php endif; ?>

	<?php if( $karatok['carouselon2'] && is_home() && $paged < 2 ) : ?>
	<div class="homecarouselbox mf tlf tf df fc cf">
		<h3 class="h4 judul-carouselhome"><?php echo $karatok['carouseltitle2']; ?></h3>
		<div class="homecarousel-pagination homecarousel2">
			<span class="prev"><i class="fa fa-angle-left"></i></span>
			<span class="next"><i class="fa fa-angle-right"></i></span>
		</div>
		<div id="homecarousel2" class="owl-carousel owl-theme">
			<?php $args = array(
							'posts_per_page'  => $karatok['jumlahcarousel2'],
							'post_type'    => 'post',
							'post_status'  => 'publish',
							'cat' => $karatok['carouselcat2']
						);
			$query = new WP_Query( $args );
			if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
				<?php get_template_part( 'entry', 'content' ); ?>
			<?php endwhile; endif; wp_reset_query();?>
		</div>
	</div>
	<?php endif; ?>

	<?php if( $karatok['carouselon3'] && is_home() && $paged < 2 ) : ?>
	<div class="homecarouselbox mf tlf tf df fc cf">
		<h3 class="h4 judul-carouselhome"><?php echo $karatok['carouseltitle3']; ?></h3>
		<div class="homecarousel-pagination homecarousel3">
			<span class="prev"><i class="fa fa-angle-left"></i></span>
			<span class="next"><i class="fa fa-angle-right"></i></span>
		</div>
		<div id="homecarousel3" class="owl-carousel owl-theme">
			<?php $args = array(
							'posts_per_page'  => $karatok['jumlahcarousel3'],
							'post_type'    => 'post',
							'post_status'  => 'publish',
							'cat' => $karatok['carouselcat3']
						);
			$query = new WP_Query( $args );
			if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
				<?php get_template_part( 'entry', 'content' ); ?>
			<?php endwhile; endif; wp_reset_query();?>
		</div>
	</div>
	<?php endif; ?>
<?php } ?>
