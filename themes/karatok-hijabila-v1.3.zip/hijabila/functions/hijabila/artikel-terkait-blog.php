<?php
function karatok_artikel_terkait_blog() {
	global $post; ?>
	<section id="A-terkait-blog" class="A-terkait-blog twelvecol first cf">
	<?php
		$custom_taxterms = wp_get_object_terms( $post->ID, 'custom_cat', array('fields' => 'ids') );
		// arguments
		$args = array(
			'post_type' => 'custom_type',
			'post_status' => 'publish',
			'posts_per_page' => 4, // you may edit this number
			'orderby' => 'rand',
			'tax_query' => array(
				array(
					'taxonomy' => 'custom_cat',
					'field' => 'id',
					'terms' => $custom_taxterms
				)
			),
			'post__not_in' => array ($post->ID),
		);
		$related_items = new WP_Query( $args );
		// loop over query
		if ($related_items->have_posts()) : ?>
			<h3 class="h5 judul-blog-terkait entry-head"><span>Artikel Terkait</span></h3>
			<ul>
			<?php while ( $related_items->have_posts() ) : $related_items->the_post(); ?>
				<li class="m6 tl4 t3 d3 cf">
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
						<div class="thumb-blog-terkait">
							<?php the_post_thumbnail('medium'); ?>
						</div>
						<h4 class="judul-artikel-terkait"><?php the_title(); ?></h4>
					</a>
				</li>
			<?php endwhile; ?>
			</ul>
		<?php endif; ?>
		<?php wp_reset_query(); ?>
	</section>

<?php } ?>
