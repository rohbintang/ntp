<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="cf">

					<div id="main" class="mf tlf t9 d9 lc cf" role="main">

						<div id="breadcrumbs" class="breadcrumbs cf"><?php karatok_breadcrumbs() ?></div>

						<h1 class="archive-title h2"><span><?php post_type_archive_title(); ?></span></h1>

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">

								<section class="entry-blog-content cf">
									<div class="entry-thumb-blog mf tlf t4 d4 fc cf">
										<?php the_post_thumbnail('large'); ?>
									</div>

									<div class="entry-summary mf tlf t8 d8 lc cf">
									<h3 class="h2"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
									<p class="byline vcard"><?php
										printf( __( '<time class="updated e-meta" datetime="%1$s"><i class="fa fa-clock-o"></i>%2$s</time> <span class="author e-meta"><i class="fa fa-user"></i>%3$s</span> <span class="e-meta"><i class="fa fa-folder"></i> %4$s</span>', 'hijabila' ), get_the_time( 'Y-m-j' ), get_the_time( __( 'F jS, Y', 'hijabila' ) ), karatok_get_the_author_posts_link(), get_the_term_list( $post->ID, 'custom_cat', ' ', ', ', '' ) );
									?></p>

									<?php the_excerpt(); ?>
									</div>

								</section>

							</article>

							<?php endwhile; ?>

									<?php if ( function_exists( 'karatok_page_navi' ) ) { ?>
											<?php karatok_page_navi(); ?>
									<?php } else { ?>
											<nav class="wp-prev-next">
													<ul class="clearfix">
														<li class="prev-link"><?php next_posts_link( __( '&laquo; Older Entries', 'hijabila' )) ?></li>
														<li class="next-link"><?php previous_posts_link( __( 'Newer Entries &raquo;', 'hijabila' )) ?></li>
													</ul>
											</nav>
									<?php } ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
										<header class="article-header">
											<h1><?php _e( 'Oops, Post Not Found!', 'hijabila' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'hijabila' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php _e( 'This is the error message in the custom posty type archive template.', 'hijabila' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>

						</div>

						<?php get_sidebar('blog'); ?>

					</div>

			</div>

<?php get_footer(); ?>
