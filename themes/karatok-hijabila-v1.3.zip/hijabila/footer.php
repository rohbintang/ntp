				<footer class="footer" role="contentinfo">
					<div id="inner-footer" class="cf">
						<nav class="footer-navigation mf tlf tf df fc cf" role="navigation">
							<?php karatok_footer_links(); ?>
						</nav>
						<div class="main-footer cf">
							<?php get_sidebar('footer'); ?>
						</div>
						<div class="copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo( 'name' ); ?>. All Rights Reserved. <?php do_action( 'karatok_credit' ); ?></div>
					</div>
				</footer>
		</div>
		<div class="sb-slidebar sb-left">
			<nav>
				<?php karatok_sliderbar_nav(); ?>
			</nav>
		</div>

		<?php wp_footer(); ?>
		<p id="back-top">
			<a href="#top"><span><i class="fa fa-angle-up fa-lg"></i>top</span></a>
		</p><!-- // End of back-top -->

	</body>

</html>
