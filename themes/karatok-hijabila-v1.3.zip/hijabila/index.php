<?php get_header(); ?>

			<section id="content">

				<div id="inner-content" class="cf">

						<section id="main" class="mf tlf t9 d9 lc cf" role="main">

							<?php karatok_home_slider_carousel(); ?>

							<h3 class="h4 home-produk-baru cf"><?php echo $karatok['produktitle']; ?></h3>

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php get_template_part( 'entry', 'content' ); ?>
							<?php endwhile; ?>

								<?php if ( function_exists( 'karatok_page_navi' ) ) { ?>
										<?php karatok_page_navi(); ?>
								<?php } else { ?>
										<nav class="wp-prev-next">
												<ul class="clearfix">
													<li class="prev-link"><?php next_posts_link( __( '&laquo; Older Entries', 'hijabila' )) ?></li>
													<li class="next-link"><?php previous_posts_link( __( 'Newer Entries &raquo;', 'hijabila' )) ?></li>
												</ul>
										</nav>
								<?php } ?>

								<?php karatok_artikel_terbaru(); ?>

							<?php else : ?>

								<article id="post-not-found" class="hentry clearfix">
										<header class="article-header">
											<h1><?php _e( 'Oops, Post Not Found!', 'hijabila' ); ?></h1>
									</header>
										<section class="entry-content">
											<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'hijabila' ); ?></p>
									</section>
									<footer class="article-footer">
											<p><?php _e( 'This is the error message in the index.php template.', 'hijabila' ); ?></p>
									</footer>
								</article>

							<?php endif; ?>

						</section>

						<?php get_sidebar(); ?>

				</div>

			</section>

<?php get_footer(); ?>
