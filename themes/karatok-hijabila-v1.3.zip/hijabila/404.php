<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="cf">

					<div id="main" class="mf tlf tf df lc cf" role="main">

						<article id="post-not-found" class="hentry cf">


							<section class="entry-content">
								<div class="bungkus-404 text-center">
									<i class="fa fa-frown-o"></i>
									<h1><?php _e( '404', 'hijabila' ); ?></h1>
									<h3 class="h1">Halaman tidak ditemukan</h3>

									<p><?php _e( 'Produk atau artikel yang anda cari tidak ditemukan, silahkan coba dengan kata kunci lainnya!', 'hijabila' ); ?></p>

									<div class="404-search"><?php get_search_form(); ?></div>
								
								</div>

							</section>

						</article>

					</div>

				</div>

			</div>

<?php get_footer(); ?>
