<!doctype html>

<!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->

	<head>
		<meta charset="utf-8">

		<?php global $karatok; ?>

		<title><?php wp_title( '|', true, 'right' ); ?></title>

		<?php // mobile meta (hooray!) ?>
		<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

		<link rel="apple-touch-icon" href="<?php echo $karatok['favicon']['url']; ?>">
		<link rel="icon" href="<?php echo $karatok['favicon']['url']; ?>">
		<!--[if IE]>
		<link rel="shortcut icon" href="<?php echo $karatok['favicon']['url']; ?>">
		<![endif]-->
		<?php // or, set /favicon.ico for IE10 win ?>
		<meta name="msapplication-TileImage" content="<?php echo $karatok['favicon']['url']; ?>">
		<meta name="msapplication-TileColor" content="<?php echo $karatok['opt-link-color']['hover']; ?>">

		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

		<?php wp_head(); ?>

	</head>

	<body <?php body_class(); ?>>

			<div id="container" class="sb-site-container wrap cf">

				<header class="header" role="banner">

					<div id="inner-header" class="inner-header cf">

						<section class="h6 top-header cf">
							<div class="top-header-left mf tlf t6 d6 fc marquee"><?php echo $karatok['welcome']; ?></div>

							<div class="top-header-right mf tlf t6 d6 lc">
								<div class="social-header">
									<ul>
										<?php if( $karatok['facebook'] ) : ?>
										<li><a href="<?php echo $karatok['facebook']; ?>"><i class="fa fa-facebook"></i>facebook</a></li>
										<?php endif; ?>
										<?php if( $karatok['twitter'] ) : ?>
										<li><a href="<?php echo $karatok['twitter']; ?>"><i class="fa fa-twitter"></i>twitter</a></li>
										<?php endif; ?>
										<?php if( $karatok['googleplus'] ) : ?>
										<li><a href="<?php echo $karatok['googleplus']; ?>"><i class="fa fa-google-plus"></i>google +</a></li>
										<?php endif; ?>
										<?php if( $karatok['instagram'] ) : ?>
										<li><a href="<?php echo $karatok['instagram']; ?>"><i class="fa fa-instagram"></i>instagram</a></li>
										<?php endif; ?>
										<?php if( $karatok['pinterest'] ) : ?>
										<li><a href="<?php echo $karatok['pinterest']; ?>"><i class="fa fa-pinterest"></i>pinterest</a></li>
										<?php endif; ?>
									</ul>
								</div>
							</div>

						</section>

						<section class="main-header cf">

							<nav id="resnavi" class="resnavi">
								<div class="sb-toggle-left">
									<div class="menu-bars">
										<div class="menu-line"></div>
										<div class="menu-line"></div>
										<div class="menu-line"></div>
									</div>
								</div>
								<div class="h1 resjudul"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></div>
								<div class="ressearch-icon lc"><i class="fa fa-search"></i></div>
							</nav>

							<div id="logo" class="logo mf tlf t3 d3 fc">
								<?php if ( ! is_singular() ) { echo '<h1>'; } ?><a class="h1" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( get_bloginfo( 'name' ), 'hijabila' ); ?>" rel="home"><?php if( $karatok['logo']['url'] ) : ?><img src="<?php echo $karatok['logo']['url']; ?>" alt="<?php echo esc_html( get_bloginfo( 'name' ) ); ?>"><?php else : ?><?php echo esc_html( get_bloginfo( 'name' ) ); ?><?php endif; ?></a><?php if ( ! is_singular() ) { echo '</h1>'; } ?>
								<?php if( $karatok['deskripsion'] ) : ?><p class="site-description"><?php bloginfo( 'description' ); ?></p><?php endif; ?>
							</div>

							<div id="hijabila-search" class="search-box mf tl7 t5 d6">
								<?php get_search_form(); ?>
							</div>


							<div id="hijabila-cart" class="cart-box mf tl5 t4 d3 lc">
								<?php if( !is_page( $karatok['checkoutpage'] ) ) : ?><div id="jcart" style="display:none"><?php karatok_display_jcart(); ?></div><?php endif; ?>

								<div class="cart-menu cf">
									<ul>
										<li class="cart-num">Rp 0</li><!--
										--><li class="cart-item">0 item</li><!--
										--><li class="checkout"><a href="<?php echo get_permalink( $karatok['checkoutpage'] ); ?>"><i class="fa fa-shopping-cart"></i><?php //echo get_the_title( $karatok['checkoutpage'] ); ?></a></li>
									</ul>
								</div>
							</div>

						</section>

						<nav class="navi" role="navigation">
							<?php karatok_main_nav(); ?>
						</nav>

					</div>

				</header>
