<article <?php post_class( 'product-box m6 tl4 t3 d3 cf' ); ?>>
	<header class="article-header">
		<?php extract(karatok_post_meta()); ?>
		<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
			<div class="entry-thumb">
				<?php the_post_thumbnail('medium'); ?>
				<?php if( $stok == 'habis' ) : ?>
					<div class="product-stockbg">
						<div class="product-stock"><?php global $karatok; echo $karatok['stokhabis']; ?></div>
					</div>
				<?php endif; ?>

				<?php if( $label ) : ?>
				<div class="product-label <?php echo strtolower( $label ); ?>">
					<span><?php echo $label; ?></span>
				</div>
				<?php endif; ?>
			</div>
			<h2 class="h4 entry-title-box"><?php the_title(); ?></h2>
		</a>
	</header>

	<footer class="article-footer footer-box-home cf">
		<div class="price-discount df">
			<p class="home-price fc"><?php karatok_price( $hargadiskon ); ?></p>
			<?php if( $diskon ) : ?>
			<p class="home-discount lc"><?php karatok_price( $harganormal ); ?></p>
			<?php endif; ?>
		</div>

		<div class="footer-box-cart mf tlf tf df">
			<div class="footer-discountpercent m5 tl6 t6 d6 fc"><?php if( $diskon ) echo $diskon."% OFF"; ?></div>
			<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="footer-addcart m7 tl6 t6 d6 lc">detail<i class="fa fa-info-circle"></i></a>
		</div>

	</footer>

</article>
