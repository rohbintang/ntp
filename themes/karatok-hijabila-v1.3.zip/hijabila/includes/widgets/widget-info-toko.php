<?php
add_action( 'widgets_init', 'karatok_infotoko_widget_init' );
function karatok_infotoko_widget_init() {
	register_widget( 'karatok_infotoko_widget' );
}
class karatok_infotoko_widget extends WP_Widget {

	function karatok_infotoko_widget() {
		$widget_ops = array( 'classname' => 'infotoko-widget cf', 'description' => 'Tampilkan informasi deskripsi toko'  );
		$this->WP_Widget( 'infotoko-widget', 'Karatok Informasi Toko', $widget_ops );
	}

	function widget( $args, $instance ) {
		global $karatok;
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );

		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;	?>
		<div class="info-toko clearfix">
			<div class="h5"><?php echo $instance['namatoko']; ?></div>
			<div class="keterangan-toko"><?php echo wpautop( $instance['deskripsi'] ); ?></div>

			<?php if( $instance['petatoko'] ) : ?>
			<div class="bungkus-map">
				<?php karatok_google_maps(); ?>
			</div>
			<?php endif; ?>
			<?php if( $instance['social'] ) : ?>
			<ul>
				<li class="social-toko"><a href="<?php echo $karatok['facebook']; ?>"><i class="fa fa-facebook"></i></a></li>
				<li class="social-toko"><a href="<?php echo $karatok['twitter']; ?>"><i class="fa fa-twitter"></i></a></li>
				<li class="social-toko"><a href="<?php echo $karatok['googleplus']; ?>"><i class="fa fa-google-plus"></i></a></li>
				<li class="social-toko"><a href="<?php echo $karatok['pinterest']; ?>"><i class="fa fa-pinterest"></i></a></li>
				<li class="social-toko"><a href="<?php echo $karatok['instagram']; ?>"><i class="fa fa-instagram"></i></a></li>
			</ul>
			<?php endif; ?>
		</div>
	<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['namatoko'] = strip_tags( $new_instance['namatoko'] );
		$instance['deskripsi'] = strip_tags( $new_instance['deskripsi'] );
		$instance['petatoko'] = strip_tags( $new_instance['petatoko'] );
		$instance['social'] = strip_tags( $new_instance['social'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array(
						'title' =>__( 'Informasi Toko' , 'karatok'),
						'namatoko' =>__( 'Toko Sandal Jepit' , 'karatok'),
						'deskripsi' =>__( 'Kami menjual segala jenis sandal jepit dengan desain lucu dan pilihan warna-warna cerah dan menggunakan bahan pilihan.' , 'karatok'),
						'petatoko' => 1,
						'social' => 1,
					);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">Title: </label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" type="text" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'namatoko' ); ?>">Nama Toko: </label>
			<input id="<?php echo $this->get_field_id( 'namatoko' ); ?>" name="<?php echo $this->get_field_name( 'namatoko' ); ?>" value="<?php echo $instance['namatoko']; ?>" class="widefat" type="text" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'deskripsi' ); ?>">Deskripsi: </label>
			<textarea id="<?php echo $this->get_field_id( 'deskripsi' ); ?>" name="<?php echo $this->get_field_name( 'deskripsi' ); ?>" class="widefat" rows="5"><?php echo $instance['deskripsi']; ?></textarea>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'petatoko' ); ?>">Tampilkan Peta: </label>
			<input id="<?php echo $this->get_field_id( 'petatoko' ); ?>" name="<?php echo $this->get_field_name( 'petatoko' ); ?>" value="1" class="widefat" type="checkbox" <?php checked( 1, $instance['petatoko'] ); ?> />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'social' ); ?>">Tampilkan Social: </label>
			<input id="<?php echo $this->get_field_id( 'social' ); ?>" name="<?php echo $this->get_field_name( 'social' ); ?>" value="1" class="widefat" type="checkbox" <?php checked( 1, $instance['social'] ); ?> />
		</p>
	<?php
	}
}
?>