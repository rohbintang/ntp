<?php
add_action( 'widgets_init', 'karatok_kontak_widget_init' );
function karatok_kontak_widget_init() {
	register_widget( 'karatok_kontak_widget' );
}
class karatok_kontak_widget extends WP_Widget {

	function karatok_kontak_widget() {
		$widget_ops = array( 'classname' => 'kontak-widget cf', 'description' => 'Tampilkan daftar kontak CS toko'  );
		$this->WP_Widget( 'kontak-widget', 'Karatok Kontak', $widget_ops );
	}

	function widget( $args, $instance ) {
		global $karatok;
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );

		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;	?>
		<ul>
			<?php foreach( $karatok['kontak'] as $kontak ) : ?>
			<?php $kontak = explode( '|', $kontak ); ?>
			<?php if( preg_match( '/YM/', $kontak[0] ) ) $kontak[1] = "<a href='ymsgr:sendim?{$kontak[1]}'><img src='http://opi.yahoo.com/online?u={$kontak[1]}&amp;m=g&amp;t=1' alt='{$kontak[1]}'/></a>"; ?>
			<li>
				<span class="nama-kontak"><?php echo $kontak[0]; ?></span>
				<span class="kontak-list"><?php echo $kontak[1]; ?></span>
			</li>
			<?php endforeach; ?>
		</ul>
	<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'title' =>__( 'Kontak Pemesanan' , 'karatok') );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">Title: </label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" type="text" />
		</p>
	<?php
	}
}
?>
