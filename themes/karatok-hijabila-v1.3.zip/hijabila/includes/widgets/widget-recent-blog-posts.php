<?php
add_action( 'widgets_init', 'recent_blog_posts_widget_init' );
function recent_blog_posts_widget_init() {
	register_widget( 'recent_blog_posts_widget' );
}
class recent_blog_posts_widget extends WP_Widget {
	function recent_blog_posts_widget() {
		$widget_ops = array( 'classname' => 'recent-blog-posts-widget cf', 'description' => 'Tampilkan artikel-artikel terbaru dari blog'  );
		$this->WP_Widget( 'recent-blog-posts-widget', 'Karatok Artikel Blog Terbaru', $widget_ops );
	}

	function widget( $args, $instance ) {
		global $post;
		extract($args);

		// Widget options
		$title 	 = apply_filters('widget_title', $instance['title'] );
		$number	 = $instance['number'];

        // Output
		echo $before_widget;

	    if ( $title ) echo $before_title . $title . $after_title;

		$mlq = new WP_Query(
					array(
						'post_type' => 'custom_type',
						'showposts' => $number
					)
				);
		if( $mlq->have_posts() ) : while($mlq->have_posts()) : $mlq->the_post(); ?>
		   <article <?php post_class( 'produk-widget clearfix' ); ?> role="article">
				<div class="box-entry">
					<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
						<div class="entry-thumb-widget">
							<?php the_post_thumbnail('thumbnail'); ?>
						</div>
						<h3 class="entry-title-widget"><?php the_title(); ?></h3>
					</a>
				</div>
			</article>
		<?php endwhile; endif; wp_reset_query();
		echo $after_widget;
	}

	/** Widget control update */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']  = strip_tags( $new_instance['title'] );
		$instance['number'] = strip_tags( $new_instance['number'] );
		return $instance;
	}

	/**
	* Widget settings
	**/
	function form( $instance ) {
		$title  = $instance['title'] ? $instance['title'] : 'Artikel Terbaru';
		$number = $instance['number'] ? $instance['number'] : 10;

		// The widget form
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php echo __( 'Title:' ); ?></label>
			<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" class="widefat" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('number'); ?>"><?php echo __( 'Number of posts to show:' ); ?></label>
			<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" />
		</p>
	<?php
	}
}
?>
