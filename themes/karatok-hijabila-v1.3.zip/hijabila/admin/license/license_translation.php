<?php
global $dlh_license_translation;
$dlh_license_translation = array (
	'menu' => __('License',SHORT_NAME),
	'title' => __('License',SHORT_NAME),
	'congratulations' =>  __('Congratulations!',SHORT_NAME),
	'activated' => __('This theme has been activated.',SHORT_NAME),
	'setting' =>  __('Please setting your theme at',SHORT_NAME),
	'theme_options' => __('Theme Options',SHORT_NAME),
	'previously' => __('',SHORT_NAME),
	'to_use' => __('To use this theme please enter your license key and save, then click "Activate License" button.',SHORT_NAME),
	'purchase_receipt' => sprintf(__('<a href="%s" target="_blank">Get The License Key</a>',SHORT_NAME), 'http://www.karatok.com/'),
	'email_receipt' => __('If you have a problem, please',SHORT_NAME),
	'support_item' => __('Support Item',SHORT_NAME),
	'support' => __('contact us',SHORT_NAME),
	'your_inquiry' => __('.',SHORT_NAME),
	'license_key' => __('License Key',SHORT_NAME),
	'enter_license_key' => __('Enter your license key',SHORT_NAME),
	'activate_license' => __('Activate License',SHORT_NAME),
	'active' => __('active',SHORT_NAME),
	'inactive' => __('inactive',SHORT_NAME),
	'deactivate_license' => __('Deactivate License',SHORT_NAME),
	'activate_license' => __('Activate License',SHORT_NAME)
);
?>