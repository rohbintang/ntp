<?php

/**
  ReduxFramework Sample Config File
  For full documentation, please visit: https://docs.reduxframework.com
 * */

if (!class_exists('Redux_Framework_sample_config')) {

    class Redux_Framework_sample_config {

        public $args        = array();
        public $sections    = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {

            if (!class_exists('ReduxFramework')) {
                return;
            }

            // This is needed. Bah WordPress bugs.  ;)
            if (  true == Redux_Helpers::isTheme(__FILE__) ) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);
            }

        }

        public function initSettings() {

            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            // If Redux is running as a plugin, this will remove the demo notice and links
            //add_action( 'redux/loaded', array( $this, 'remove_demo' ) );

            // Function to test the compiler hook and demo CSS output.
            // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
            //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 2);

            // Change the arguments after they've been declared, but before the panel is created
            //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );

            // Change the default value of a field after it's been set, but before it's been useds
            //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

            // Dynamically add a section. Can be also used to modify sections/fields
            //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        /**

          This is a test function that will let you see when the compiler hook occurs.
          It only runs if a field	set with compiler=>true is changed.

         * */
        function compiler_action($options, $css) {
            //echo '<h1>The compiler hook has run!';
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

            /*
              // Demo of how to use the dynamic CSS and write your own static CSS file
              $filename = dirname(__FILE__) . '/style' . '.css';
              global $wp_filesystem;
              if( empty( $wp_filesystem ) ) {
                require_once( ABSPATH .'/wp-admin/includes/file.php' );
              WP_Filesystem();
              }

              if( $wp_filesystem ) {
                $wp_filesystem->put_contents(
                    $filename,
                    $css,
                    FS_CHMOD_FILE // predefined mode settings for WP files
                );
              }
             */
        }

        /**

          Custom function for filtering the sections array. Good for child themes to override or add to the sections.
          Simply include this function in the child themes functions.php file.

          NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
          so you must use get_template_directory_uri() if you want to use any of the built in icons

         * */
        function dynamic_section($sections) {
            //$sections = array();
            $sections[] = array(
                'title' => __('Section via hook', 'redux-framework-demo'),
                'desc' => __('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'redux-framework-demo'),
                'icon' => 'el-icon-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }

        /**

          Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.

         * */
        function change_arguments($args) {
            //$args['dev_mode'] = true;

            return $args;
        }

        /**

          Filter hook for filtering the default value of any given field. Very useful in development mode.

         * */
        function change_defaults($defaults) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }

        // Remove the demo link and the notice of integrated demo from the redux-framework plugin
        function remove_demo() {

            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if (class_exists('ReduxFrameworkPlugin')) {
                remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), null, 2);

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
            }
        }

        public function setSections() {
            ob_start();

            $ct             = wp_get_theme();
            $this->theme    = $ct;
            $item_name      = $this->theme->get('Name');
            $tags           = $this->theme->Tags;
            $screenshot     = $this->theme->get_screenshot();
            $class          = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(__('Customize &#8220;%s&#8221;', 'redux-framework-demo'), $this->theme->display('Name'));

            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_attr_e('Current theme preview'); ?>" />
                <?php endif; ?>

                <h4><?php echo $this->theme->display('Name'); ?></h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(__('By %s', 'redux-framework-demo'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(__('Version %s', 'redux-framework-demo'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . __('Tags', 'redux-framework-demo') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description"><?php echo $this->theme->display('Description'); ?></p>
            <?php
            if ($this->theme->parent()) {
                printf(' <p class="howto">' . __('This <a href="%1$s">child theme</a> requires its parent theme, %2$s.') . '</p>', __('http://codex.wordpress.org/Child_Themes', 'redux-framework-demo'), $this->theme->parent()->display('Name'));
            }
            ?>

                </div>
            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();

            // ACTUAL DECLARATION OF SECTIONS
            $this->sections[] = array(
                'title'     => __('Home Settings', 'redux-framework-demo'),
                'desc'      => __('Untuk setting tampilan Home', 'redux-framework-demo'),
                'icon'      => 'el-icon-home',
                'fields'    => array(
                    array(
                        'id'        => 'modalon',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Welcome Modal', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan welcome modal pada visitor baru.', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'modalcookie',
                        'type'      => 'slider',
                        'required'  => array('modalon', '=', '1'),
                        'title'     => __('Cookie Modal', 'redux-framework-demo'),
                        'subtitle'  => __('Berapa hari cookie modal akan expires?<br>Default 7 hari, isi 0 modal akan selalu tampil.', 'redux-framework-demo'),
                        'default'   => 7,
                        'min'       => 0,
                        'step'      => 1,
                        'max'       => 30,
                        'display_value' => 'label',
                    ),
                    array(
                        'id'        => 'modaltype',
                        'type'      => 'button_set',
                        'required'  => array('modalon', '=', '1'),
                        'title'     => __('Pilih Welcome Modal', 'redux-framework-demo'),
                        'options'  => array(
							'1' => 'Gambar',
							'2' => 'HTML'
						),
                        'default'   => 1,
                    ),
                    array(
                        'id'        => 'modalgambar',
                        'type'      => 'slides',
                        'single'    => true,
                        'required'  => array('modaltype', '=', '1'),
                        'title'     => __('Gambar Modal', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan gambar welcome modal', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'modalhtml',
                        'type'      => 'textarea',
                        'required'  => array('modaltype', '=', '2'),
                        'title'     => __('Modal HTML', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan HTML welcome modal.', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'favicon',
                        'type'      => 'media',
                        'title'     => __('Favicon', 'redux-framework-demo'),
                        'default'   => array( 'url' => get_template_directory_uri() . '/favicon.ico', )
                    ),
                    array(
                        'id'        => 'logo',
                        'type'      => 'media',
                        'title'     => __('Logo', 'redux-framework-demo'),
                        'subtitle'  => __('Upload logo, ukuran maximal 255px x 60px.', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'deskripsion',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Deskripsi', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan Tagline pada menu Setting > General.', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'welcome',
                        'type'      => 'textarea',
                        'title'     => __('Welcome Message', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan tulisan berjalan di top header kiri atas.', 'redux-framework-demo'),
                        'default'   => 'Selamat datang di toko online <a href="http://www.karatok.com/">Karatok Akentokan</a> yang selalu siap melayani Anda pagi, siang, sore, dan malam.',
                    ),
                    array(
                        'id'        => 'slideron',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Slider', 'redux-framework-demo'),
                        'default'   => false,
                    ),
                    array(
                        'id'        => 'homeslides',
                        'type'      => 'slides',
                        'required'  => array('slideron', '=', '1'),
                        'title'     => __('Slides Options', 'redux-framework-demo'),
                        'subtitle'  => __('Unlimited slider, bisa ditambahkan sesuai kebutuhan. Ukuran lebar gambar adalah <b>810px</b> dan tinggi bisa disesuaikan.', 'redux-framework-demo'),
                        'placeholder'   => array(
                            'title'         => __('Title', 'redux-framework-demo'),
                            'description'   => __('Description', 'redux-framework-demo'),
                            'url'           => __('Link', 'redux-framework-demo'),
                        ),
                    ),
                    array(
                        'id'        => 'carouselon',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Carousel', 'redux-framework-demo'),
                        'default'   => false,
                    ),
                    array(
                        'id'        => 'carouseltitle',
                        'type'      => 'text',
                        'required'  => array('carouselon', '=', '1'),
                        'title'     => __('Judul Carousel', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan judul kategori carousel', 'redux-framework-demo'),
                        'default'   => 'Judul Carousel',
                    ),
                    array(
                        'id'        => 'carouselcat',
                        'type'      => 'select',
                        'required'  => array('carouselon', '=', '1'),
                        'data'      => 'categories',
                        'title'     => __('Kategori Carousel', 'redux-framework-demo'),
                        'subtitle'  => __('Pilih kategori carousel', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'jumlahcarousel',
                        'type'      => 'slider',
                        'required'  => array('carouselon', '=', '1'),
                        'title'     => __('Jumlah Carousel', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan jumlah produk di carousel', 'redux-framework-demo'),
                        'default'   => 10,
                        'min'       => 1,
                        'step'      => 1,
                        'max'       => 20,
                        'display_value' => 'label',
                    ),
                    array(
                        'id'        => 'carouselon2',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Carousel 2', 'redux-framework-demo'),
                        'default'   => false,
                    ),
                    array(
                        'id'        => 'carouseltitle2',
                        'type'      => 'text',
                        'required'  => array('carouselon2', '=', '1'),
                        'title'     => __('Judul Carousel 2', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan judul kategori carousel', 'redux-framework-demo'),
                        'default'   => 'Judul Carousel',
                    ),
                    array(
                        'id'        => 'carouselcat2',
                        'type'      => 'select',
                        'required'  => array('carouselon2', '=', '1'),
                        'data'      => 'categories',
                        'title'     => __('Kategori Carousel 2', 'redux-framework-demo'),
                        'subtitle'  => __('Pilih kategori carousel', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'jumlahcarousel2',
                        'type'      => 'slider',
                        'required'  => array('carouselon2', '=', '1'),
                        'title'     => __('Jumlah Carousel 2', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan jumlah produk di carousel', 'redux-framework-demo'),
                        'default'   => 10,
                        'min'       => 1,
                        'step'      => 1,
                        'max'       => 20,
                        'display_value' => 'label',
                    ),
                    array(
                        'id'        => 'carouselon3',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Carousel 3', 'redux-framework-demo'),
                        'default'   => false,
                    ),
                    array(
                        'id'        => 'carouseltitle3',
                        'type'      => 'text',
                        'required'  => array('carouselon3', '=', '1'),
                        'title'     => __('Judul Carousel 3', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan judul kategori carousel', 'redux-framework-demo'),
                        'default'   => 'Judul Carousel',
                    ),
                    array(
                        'id'        => 'carouselcat3',
                        'type'      => 'select',
                        'required'  => array('carouselon3', '=', '1'),
                        'data'      => 'categories',
                        'title'     => __('Kategori Carousel 3', 'redux-framework-demo'),
                        'subtitle'  => __('Pilih kategori carousel', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'jumlahcarousel3',
                        'type'      => 'slider',
                        'required'  => array('carouselon3', '=', '1'),
                        'title'     => __('Jumlah Carousel 3', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan jumlah produk di carousel', 'redux-framework-demo'),
                        'default'   => 10,
                        'min'       => 1,
                        'step'      => 1,
                        'max'       => 20,
                        'display_value' => 'label',
                    ),
                    array(
                        'id'        => 'produktitle',
                        'type'      => 'text',
                        'title'     => __('Judul Produk Terbaru', 'redux-framework-demo'),
                        'default'   => 'Produk Terbaru',
                    ),
                    array(
                        'id'        => 'artikelon',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Artikel Terbaru', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan artikel blog di halaman home', 'redux-framework-demo'),
                        'default'   => false,
                    ),
                    array(
                        'id'        => 'artikeltitle',
                        'type'      => 'text',
                        'required'  => array('artikelon', '=', '1'),
                        'title'     => __('Title', 'redux-framework-demo'),
                        'default'   => 'Artikel Blog',
                    ),
                    array(
                        'id'        => 'jumlahartikel',
                        'type'      => 'slider',
                        'required'  => array('artikelon', '=', '1'),
                        'title'     => __('Jumlah Artikel', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan jumlah artikel yang akan ditampilkan', 'redux-framework-demo'),
                        'default'   => 5,
                        'min'       => 1,
                        'step'      => 1,
                        'max'       => 20,
                        'display_value' => 'label',
                    ),
                ),
            );

            $this->sections[] = array(
                'type' => 'divide',
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-cogs',
                'title'     => __('General Settings', 'redux-framework-demo'),
                'desc'      => __('Opsi <b>Pin BB</b>, <b>Whatsapp</b>, <b>No HP</b> dan <b>email</b> akan tampil di header. <br/>Opsi <b>Facebook</b>, <b>Twitter</b>, <b>Google +</b>, <b>Pinterest</b> dan <b>Instagram</b> akan tampil di widget "Informasi Toko".', 'redux-framework-demo'),
                'fields'    => array(
                    array(
                        'id'        => 'pinbb',
                        'type'      => 'text',
                        'title'     => __('Pin BB', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan pin bb.', 'redux-framework-demo'),
                        'desc'      => __('Contoh 8649D8FF.', 'redux-framework-demo'),
                        'validate'  => 'no_special_chars',
                        'default'   => '8649D8FF'
                    ),
                    array(
                        'id'        => 'nowa',
                        'type'      => 'text',
                        'title'     => __('No WhatsApp', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan no whatsapp.', 'redux-framework-demo'),
                        'desc'      => __('Contoh 085640123456.', 'redux-framework-demo'),
                        'validate'  => 'no_special_chars',
                        'default'   => '085640123456'
                    ),
                    array(
                        'id'        => 'nohp',
                        'type'      => 'text',
                        'title'     => __('No HP', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan nomor hp.', 'redux-framework-demo'),
                        'desc'      => __('Contoh 085640123456.', 'redux-framework-demo'),
                        'validate'  => 'no_special_chars',
                        'default'   => '085640123456'
                    ),
                    array(
                        'id'        => 'email',
                        'type'      => 'text',
                        'title'     => __('Email', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan alamat email.', 'redux-framework-demo'),
                        'desc'      => __('Contoh info@karatok.com.', 'redux-framework-demo'),
                        'validate'  => 'email',
                        'default'   => 'info@karatok.com',
                    ),
                    array(
                        'id'        => 'facebook',
                        'type'      => 'text',
                        'title'     => __('Facebook', 'redux-framework-demo'),
                        'subtitle'  => __('Facebook page url.', 'redux-framework-demo'),
                        'desc'      => __('Contoh http://www.facebook.com/karatoktheme.', 'redux-framework-demo'),
                        'validate'  => 'url',
                        'default'   => 'http://www.facebook.com/karatoktheme',
                    ),
                    array(
                        'id'        => 'twitter',
                        'type'      => 'text',
                        'title'     => __('Twitter', 'redux-framework-demo'),
                        'subtitle'  => __('Twitter url.', 'redux-framework-demo'),
                        'desc'      => __('Contoh http://www.twitter.com/karatoktheme.', 'redux-framework-demo'),
                        'validate'  => 'url',
                        'default'   => 'http://www.twitter.com/Karatok',
                    ),
                    array(
                        'id'        => 'googleplus',
                        'type'      => 'text',
                        'title'     => __('Google +', 'redux-framework-demo'),
                        'subtitle'  => __('Google + url.', 'redux-framework-demo'),
                        'desc'      => __('Contoh http://plus.google.com/karatoktheme.', 'redux-framework-demo'),
                        'validate'  => 'url',
                        'default'   => 'http://plus.google.com/Karatok',
                    ),
                    array(
                        'id'        => 'pinterest',
                        'type'      => 'text',
                        'title'     => __('Pinterest', 'redux-framework-demo'),
                        'subtitle'  => __('Pinterest url.', 'redux-framework-demo'),
                        'desc'      => __('Contoh http://www.pinterest.com/karatoktheme.', 'redux-framework-demo'),
                        'validate'  => 'url',
                        'default'   => 'http://www.pinterest.com/Karatok',
                    ),
                    array(
                        'id'        => 'instagram',
                        'type'      => 'text',
                        'title'     => __('Instagram', 'redux-framework-demo'),
                        'subtitle'  => __('Instagram url.', 'redux-framework-demo'),
                        'desc'      => __('Contoh http://www.instagram.com/karatoktheme.', 'redux-framework-demo'),
                        'validate'  => 'url',
                        'default'   => 'http://www.instagram.com/Karatok',
                    ),
                )
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-website',
                'title'     => __('Layout Settings', 'redux-framework-demo'),
                'fields'    => array(
                    array(
                        'id'        => 'opt-layout',
                        'type'      => 'image_select',
                        'title'     => __('Images Option for Layout', 'redux-framework-demo'),
                        'subtitle'  => __('No validation can be done on this field type', 'redux-framework-demo'),
                        'desc'      => __('This uses some of the built in images, you can use them for layout options.', 'redux-framework-demo'),
                         'options'   => array(
                            //'1' => array('alt' => '1 Column',        'img' => ReduxFramework::$_url . 'assets/img/1col.png'),
                            '1' => array('alt' => '2 Column Left',   'img' => ReduxFramework::$_url . 'assets/img/2cl.png'),
                            '2' => array('alt' => '2 Column Right',  'img' => ReduxFramework::$_url . 'assets/img/2cr.png'),
                            //'4' => array('alt' => '3 Column Middle', 'img' => ReduxFramework::$_url . 'assets/img/3cm.png'),
                            //'5' => array('alt' => '3 Column Left',   'img' => ReduxFramework::$_url . 'assets/img/3cl.png'),
                            //'6' => array('alt' => '3 Column Right',  'img' => ReduxFramework::$_url . 'assets/img/3cr.png')
                        ),
                        'default' => '1'
                    ),
                    array(
                        'id'        => 'opt-background',
                        'type'      => 'background',
                        'output'    => array('#container'),
                        'title'     => __('Body Background', 'redux-framework-demo'),
                        'subtitle'  => __('Body background with image, color, etc.', 'redux-framework-demo'),
                        'default'   => array(
							'background-color' => '#fff',
						)
                    ),
                    array(
                        'id'        => 'opt-link-color',
                        'type'      => 'link_color',
                        'output'    => array('a'),
                        'title'     => __('Links Color Option', 'redux-framework-demo'),
                        'subtitle'  => __('Only color validation can be done on this field type', 'redux-framework-demo'),
                        //'regular'   => false, // Disable Regular Color
                        //'hover'     => false, // Disable Hover Color
                        //'active'    => false, // Disable Active Color
                        //'visited'   => true,  // Enable Visited Color
                        'default'   => array(
                            'regular'   => '#222',
                            'hover'     => '#2fc7f7',
                            'active'    => '#999',
                            'visited'   => '#999',
                        )
                    ),
                    array(
                        'id'            => 'opt-typography',
                        'type'          => 'typography',
                        'title'         => __('Typography', 'redux-framework-demo'),
                        //'compiler'      => true,  // Use if you want to hook in your own CSS compiler
                        'google'        => true,    // Disable google fonts. Won't work if you haven't defined your google api key
                        'font-backup'   => true,    // Select a backup non-google font in addition to a google font
                        //'font-style'    => false, // Includes font-style and weight. Can use font-style or font-weight to declare
                        //'subsets'       => false, // Only appears if google is true and subsets not set to false
                        'font-size'     => false,
                        'line-height'   => false,
                        'text-align'    => false,
                        //'word-spacing'  => true,  // Defaults to false
                        //'letter-spacing'=> true,  // Defaults to false
                        //'color'         => false,
                        //'preview'       => false, // Disable the previewer
                        'all_styles'    => true,    // Enable all Google Font style/weight variations to be added to the page
                        'output'        => array('body'), // An array of CSS selectors to apply this font style to dynamically
                        //'compiler'      => array('h2.site-description-compiler'), // An array of CSS selectors to apply this font style to dynamically
                        'units'         => 'px', // Defaults to px
                        'subtitle'      => __('Typography option with each property can be called individually.', 'redux-framework-demo'),
                        'default'       => array(
                            'color'         => '#222',
                            'font-family'   => 'Open Sans',
                            'font-backup'   => 'Arial, Helvetica, sans-serif',
                            'font-weight'   => 300,
                            'google'        => true),
                    ),
                )
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-check',
                'title'     => __('Single Settings', 'redux-framework-demo'),
                'desc'      => __('Pengaturan tampilan fitur-fitur pada halaman produk (halaman single) .', 'redux-framework-demo'),
                'fields'    => array(
                    array(
                        'id'        => 'tombolviasms',
                        'type'      => 'switch',
                        'title'     => __('Pesan Via SMS', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan fitur "<b>Pemesanan via SMS</b>" di halaman produk', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'formatsms',
                        'type'      => 'textarea',
                        'required'  => array('tombolviasms', '=', '1'),
                        'title'     => __('Format Pemesanan', 'redux-framework-demo'),
                        'subtitle'  => __('[nohp] akan otomatis diganti dengan no hp yang telah dimasukkan', 'redux-framework-demo'),
                        'default'   => "Kirim format SMS di bawah ke [nohp]<br/><strong>#Nama #Alamat Lengkap #Kode Produk #Jumlah Produk #Ukuran Produk</strong>",
                    ),
                    array(
                        'id'        => 'pernahdilihat',
                        'type'      => 'switch',
                        'title'     => __('Pernah Dilihat', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan fitur produk yang Pernah dilihat oleh visitor', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'jumlahpernahdilihat',
                        'type'      => 'slider',
                        'required'  => array('pernahdilihat', '=', '1'),
                        'title'     => __('Jumlah Pernah Dilihat', 'redux-framework-demo'),
                        'subtitle'  => __('Jumlah produk yang akan ditampilkan di fitur Pernah dilihat', 'redux-framework-demo'),
                        'validate'  => 'numeric',
                        'default'   => 6,
                        'min'       => 1,
                        'step'      => 1,
                        'max'       => 20,
                        'display_value' => 'label',
                    ), //single tabs
                    array(
                        'id'        => 'singletabson',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Fitur Tabs', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan produk fitur tabs (Produk Terkait, Popular, Bestseller dan Terbaru)', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'jumlahproduktabs',
                        'type'      => 'slider',
                        'required'  => array('singletabson', '=', '1'),
                        'title'     => __('Jumlah Produk', 'redux-framework-demo'),
                        'subtitle'  => __('Jumlah produk yang akan ditampilkan masing-masing tab', 'redux-framework-demo'),
                        'validate'  => 'numeric',
                        'default'   => 5,
                        'min'       => 1,
                        'step'      => 1,
                        'max'       => 20,
                        'display_value' => 'label',
                    ),
                    array(
                        'id'        => 'produkterkait',
                        'type'      => 'switch',
                        'required'  => array('singletabson', '=', '1'),
                        'title'     => __('Produk Terkait', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan Produk Terkait', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'produkpopular',
                        'type'      => 'switch',
                        'required'  => array('singletabson', '=', '1'),
                        'title'     => __('Produk Popular', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan Produk Popular', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'produkbestseller',
                        'type'      => 'switch',
                        'required'  => array('singletabson', '=', '1'),
                        'title'     => __('Produk Bestseller', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan Produk Bestseller', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'produkterbaru',
                        'type'      => 'switch',
                        'required'  => array('singletabson', '=', '1'),
                        'title'     => __('Produk Terbaru', 'redux-framework-demo'),
                        'subtitle'  => __('Menampilkan Produk Terbaru', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                )
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-fire',
                'title'     => __('Karatok Settings', 'redux-framework-demo'),
                'desc'      => __('Pengaturan Shopping Cart, halaman Testimoni, Label Produk, Informasi Toko, Rekening Bank dan Kontak Sales.', 'redux-framework-demo'),
                'fields'    => array(
                    array(
                        'id'        => 'jnefile',
                        'type'      => 'media',
                        'title'     => __('File Ongkir JNE', 'redux-framework-demo'),
                        'mode'      => false,
                        'subtitle'  => __('Upload file .csv ongkir jne.', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'ongkirnull',
                        'type'      => 'text',
                        'title'     => __('Pesan Ongkos Kirim', 'redux-framework-demo'),
                        'subtitle'  => __('Pesan di halaman checkout jika ongkir kosong (buat dropshipper).', 'redux-framework-demo'),
                        'validate'  => 'not_empty',
                        'default'   => 'Ongkos kirim akan kami konfirmasikan.'
                    ),
                    array(
                        'id'        => 'testipage',
                        'type'      => 'select',
                        'data'      => 'pages',
                        'title'     => __('Testimoni Page', 'redux-framework-demo'),
                        'subtitle'  => __('Pilih halaman testimoni', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'checkoutpage',
                        'type'      => 'select',
                        'data'      => 'pages',
                        'title'     => __('Checkout page', 'redux-framework-demo'),
                        'subtitle'  => __('Pilih halaman checkout', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'redirecttocheckout',
                        'type'      => 'switch',
                        'title'     => __('Redirect Checkout', 'redux-framework-demo'),
                        'subtitle'  => __('Redirect ke halaman checkout setelah klik button.', 'redux-framework-demo'),
                        'default'   => false,
                    ),
                    array(
                        'id'        => 'buttontexton',
                        'type'      => 'switch',
                        'title'     => __('Tampilkan Button Add To Cart', 'redux-framework-demo'),
                        'subtitle'  => __('Tampilkan button "add to cart" di halaman single.', 'redux-framework-demo'),
                        'default'   => true,
                    ),
                    array(
                        'id'        => 'buttontext',
                        'type'      => 'text',
                        'required'  => array('buttontexton', '=', '1'),
                        'title'     => __('Button Text', 'redux-framework-demo'),
                        'subtitle'  => __('Teks "add to cart" di halaman single.', 'redux-framework-demo'),
                        'validate'  => 'not_empty',
                        'default'   => 'add to cart'
                    ),
                    array(
                        'id'        => 'stokhabis',
                        'type'      => 'text',
                        'title'     => __('Pesan Stok Habis', 'redux-framework-demo'),
                        'subtitle'  => __('Label teks produk di gambar produk.', 'redux-framework-demo'),
                        'validate'  => 'not_empty',
                        'default'   => 'sold out'
                    ),
                    array(
                        'id'        => 'namatoko',
                        'type'      => 'text',
                        'title'     => __('Nama Toko', 'redux-framework-demo'),
                        'subtitle'  => __('Nama Toko digunakan pada laporan Email jika ada order via Shopping cart.', 'redux-framework-demo'),
                        'validate'  => 'not_empty',
                        'default'   => 'Hijabila Online Shop'
                    ),
                    array(
                        'id'        => 'emailtoko',
                        'type'      => 'text',
                        'title'     => __('Email Toko', 'redux-framework-demo'),
                        'subtitle'  => __('Email digunakan untuk menerima laporan jika ada order via Shopping Cart.', 'redux-framework-demo'),
                        'validate'  => 'email',
                        'default'   => 'sales@karatok.com'
                    ),
                    array(
                        'id'        => 'alamattoko',
                        'type'      => 'textarea',
                        'title'     => __('Alamat Toko', 'redux-framework-demo'),
                        'subtitle'  => __('Alamat Toko digunakan pada laporan email jika ada order via Shopping Cart.', 'redux-framework-demo'),
                        'validate'  => 'no_html',
                        'default'   => "Jalan Pemuda No. 99\nSemarang\n085640123456"
                    ),
                    array(
                        'id'        => 'rekbank',
                        'type'      => 'multi_text',
                        'mode'      => 'text', // checkbox or text
                        'title'     => __('Rekening Bank', 'redux-framework-demo'),
                        'subtitle'  => __('(<em>Contoh: Bank|Nama|NoRek</em>)<br/> Rekening akan tampil di widget sidebar dan atau Pop up jika "Pemesanan via SMS" di halaman single diaktifkan.', 'redux-framework-demo'),
                        'default'   => array(
                            'BCA|An. Siti Hijabila|0123456789',
                            'MANDIRI|An. Siti Hijabila|1234567890',
                            'BNI|An. Siti Hijabila|2345678901',
                            'BRI|An. Siti Hijabila|3456789012',
                            'CIMB Niaga|An. Siti Hijabila|4567890123',
                            'DANAMON|An. Siti Hijabila|5678901234',
                            'MUAMALAT|An. Siti Hijabila|6789012345',
                        )
                    ),
                    array(
                        'id'        => 'kontak',
                        'type'      => 'multi_text',
                        'mode'      => 'text',
                        'title'     => __('Kontak', 'redux-framework-demo'),
                        'subtitle'  => __('(<em>Contoh: Pin BB|76ac987</em>)<br/>Kontak CS atau Sales akan tampil di widget sidebar.', 'redux-framework-demo'),
                        'default'   => array(
                            'Pin BB|0123456789',
                            'WhatsApp|1234567890',
                            'Line|2345678901',
                            'Kakao Talk|3456789012',
                            'Telp|4567890123',
                            'Email|5678901234',
                        )
                    ),
                    array(
                        'id'        => 'emailnote',
                        'type'      => 'textarea',
                        'title'     => __('Catatan Tambahan Email', 'redux-framework-demo'),
                        'subtitle'  => __('Catatan Tambahan akan ditampilkan di bawah email invoice.', 'redux-framework-demo'),
                        'validate'  => 'no_html',
                        'default'   => "Silakan lakukan pembayaran ke nomor rekening kami dan lakukan konfirmasi kepada CS kami agar pesanan Anda bisa segera kami proses."
                    ),
                    array(
                        'id'        => 'latlong',
                        'type'      => 'text',
                        'title'     => __('Latitude dan Longitude', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan latitude dan longitude, contoh -6.984143, 110.410052', 'redux-framework-demo'),
                        'validate'  => 'not_empty',
                        'default'   => '-6.984143, 110.410052'
                    ),
                )
            );

            $this->sections[] = array(
                'title'     => __('Custom Code', 'redux-framework-demo'),
                'icon'      => 'el-icon-css',
                'fields'    => array(
                    array(
                        'id'        => 'warnacss',
                        'type'      => 'textarea',
                        'title'     => __('Warna CSS', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan khusus warna css.', 'redux-framework-demo'),
                        'validate'  => 'css',
                        'default'   => ".Hitam{background-color:#000}\n.Putih{background-color:#fff}\n.Merah{background-color:#f00}\n.Hijau{background-color:#0f0}\n.Biru{background-color:#00f}\n.Kuning{background-color:#ff0}\n.Orange{background-color:#ffa500}\n.Peach{background-color:#ffdab9}\n.Aqua{background-color:#0ff}\n.Pink{background-color:#ffc0cb}\n.Ungu{background-color:#800080}\n.Violet{background-color:#ee82ee}\n.Maroon{background-color:#800000}\n.Coklat{background-color:#d2691e}\n.Abu{background-color:#808080}\n.Biru-Langit{background-color:#87ceeb}\n.Hijau-Muda{background-color:#00ff7f}",
                    ),
                    array(
                        'id'        => 'customcss',
                        'type'      => 'textarea',
                        'title'     => __('Custom CSS', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan custom css.', 'redux-framework-demo'),
                        'validate'  => 'css',
                    ),
                    array(
                        'id'        => 'customjs',
                        'type'      => 'textarea',
                        'title'     => __('Custom JS', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan custom javascript', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'googleanalytics',
                        'type'      => 'textarea',
                        'title'     => __('Google Analytics', 'redux-framework-demo'),
                        'subtitle'  => __('Masukkan google analytics', 'redux-framework-demo'),
                    ),
                    array(
                        'id'        => 'credit',
                        'type'      => 'textarea',
                        'title'     => __('Credit Footer', 'redux-framework-demo'),
                        'default'   => 'Designed by <a href="http://www.karatok.com/">Karatok Theme</a>.'
                    ),
                ),
            );

            $theme_info  = '<div class="redux-framework-section-desc">';
            $theme_info .= '<p class="redux-framework-theme-data description theme-uri">' . __('<strong>Theme URL:</strong> ', 'redux-framework-demo') . '<a href="' . $this->theme->get('ThemeURI') . '" target="_blank">' . $this->theme->get('ThemeURI') . '</a></p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-author">' . __('<strong>Author:</strong> ', 'redux-framework-demo') . $this->theme->get('Author') . '</p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-version">' . __('<strong>Version:</strong> ', 'redux-framework-demo') . $this->theme->get('Version') . '</p>';
            $theme_info .= '<p class="redux-framework-theme-data description theme-description">' . $this->theme->get('Description') . '</p>';
            $tabs = $this->theme->get('Tags');
            if (!empty($tabs)) {
                $theme_info .= '<p class="redux-framework-theme-data description theme-tags">' . __('<strong>Tags:</strong> ', 'redux-framework-demo') . implode(', ', $tabs) . '</p>';
            }
            $theme_info .= '</div>';

            $this->sections[] = array(
                'title'     => __('Import / Export', 'redux-framework-demo'),
                'desc'      => __('Import and Export your settings from file, text or URL.', 'redux-framework-demo'),
                'icon'      => 'el-icon-refresh',
                'fields'    => array(
                    array(
                        'id'            => 'opt-import-export',
                        'type'          => 'import_export',
                        'title'         => 'Import Export',
                        'subtitle'      => 'Save and restore your Redux options',
                        'full_width'    => false,
                    ),
                ),
            );

            $this->sections[] = array(
                'type' => 'divide',
            );

            $this->sections[] = array(
                'icon'      => 'el-icon-info-sign',
                'title'     => __('Theme Information', 'redux-framework-demo'),
                'fields'    => array(
                    array(
                        'id'        => 'opt-raw-info',
                        'type'      => 'raw',
                        'content'   => $item_info,
                    )
                ),
            );

        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-1',
                'title'     => __('Theme Information 1', 'redux-framework-demo'),
                'content'   => __('<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo')
            );

            $this->args['help_tabs'][] = array(
                'id'        => 'redux-help-tab-2',
                'title'     => __('Theme Information 2', 'redux-framework-demo'),
                'content'   => __('<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo')
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo');
        }

        /**

          All the possible arguments for Redux.
          For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments

         * */
        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                // TYPICAL -> Change these values as you need/desire
                'opt_name'          => 'karatok',            // This is where your data is stored in the database and also becomes your global variable name.
                'display_name'      => $theme->get('Name'),     // Name that appears at the top of your panel
                'display_version'   => $theme->get('Version'),  // Version that appears at the top of your panel
                'menu_type'         => 'menu',                  //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu'    => false,                    // Show the sections below the admin menu item or not
                'menu_title'        => __('Karatok Options', 'redux-framework-demo'),
                'page_title'        => __('Karatok Options', 'redux-framework-demo'),

                // You will need to generate a Google API key to use this feature.
                // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                'google_api_key' => 'AIzaSyCM5bnBTDCbV1VFKpTPSFQ600Oeu9zOz-s', // Must be defined to add google fonts to the typography module

                'async_typography'  => false,                    // Use a asynchronous font on the front end or font string
                'admin_bar'         => false,                    // Show the panel pages on the admin bar
                'global_variable'   => 'karatok',                      // Set a different name for your global variable other than the opt_name
                'dev_mode'          => false,                    // Show the time the page took to load, etc
                'customizer'        => false,                    // Enable basic customizer support

                // OPTIONAL -> Give you extra features
                'page_priority'     => null,                    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent'       => 'themes.php',            // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions'  => 'manage_options',        // Permissions needed to access the options panel.
                'menu_icon'         => get_template_directory_uri() . '/library/images/karatok.png', // Specify a custom URL to an icon
                'last_tab'          => '',                      // Force your panel to always open to a specific tab (by id)
                'page_icon'         => 'icon-themes',           // Icon displayed in the admin panel next to your menu_title
                'page_slug'         => '_karatok',              // Page slug used to denote the panel
                'save_defaults'     => true,                    // On load save the defaults to DB before user clicks save or not
                'default_show'      => false,                   // If true, shows the default value next to each field that is not the default value.
                'default_mark'      => '',                      // What to print by the field's title if the value shown is default. Suggested: *
                'show_import_export' => true,                   // Shows the Import/Export panel when not used as a field.
                'allow_tracking'    => false,

                // CAREFUL -> These options are for advanced use only
                'transient_time'    => 60 * MINUTE_IN_SECONDS,
                'output'            => true,                    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag'        => true,                    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                'footer_credit'     => ' ',                   // Disable the footer credit of Redux. Please leave if you can help it.

                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database'              => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'system_info'           => false, // REMOVE

                // HINTS
                'hints' => array(
                    'icon'          => 'icon-question-sign',
                    'icon_position' => 'right',
                    'icon_color'    => 'lightgray',
                    'icon_size'     => 'normal',
                    'tip_style'     => array(
                        'color'         => 'light',
                        'shadow'        => true,
                        'rounded'       => false,
                        'style'         => '',
                    ),
                    'tip_position'  => array(
                        'my' => 'top left',
                        'at' => 'bottom right',
                    ),
                    'tip_effect'    => array(
                        'show'          => array(
                            'effect'        => 'slide',
                            'duration'      => '500',
                            'event'         => 'mouseover',
                        ),
                        'hide'      => array(
                            'effect'    => 'slide',
                            'duration'  => '500',
                            'event'     => 'click mouseleave',
                        ),
                    ),
                )
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
            $this->args['share_icons'][] = array(
                'url'   => 'https://www.karatok.com',
                'title' => 'Our themes',
                'icon'  => 'el-icon-website'
                //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
            );
            $this->args['share_icons'][] = array(
                'url'   => 'https://www.facebook.com/karatoktheme',
                'title' => 'Like us on Facebook',
                'icon'  => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url'   => 'http://twitter.com/karatoktheme',
                'title' => 'Follow us on Twitter',
                'icon'  => 'el-icon-twitter'
            );

            // Panel Intro text -> before the form
            if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false) {
                if (!empty($this->args['global_variable'])) {
                    $v = $this->args['global_variable'];
                } else {
                    $v = str_replace('-', '_', $this->args['opt_name']);
                }
                $this->args['intro_text'] = sprintf(__('<p>Theme option ini digunakan untuk mengatur tampilan halaman theme pada website anda.</p>', 'redux-framework-demo'), $v);
            } else {
                $this->args['intro_text'] = __('', 'redux-framework-demo');
            }

            // Add content after the form.
            $this->args['footer_text'] = __('', 'redux-framework-demo');
        }

    }

    global $reduxConfig;
    $reduxConfig = new Redux_Framework_sample_config();
}

/**
  Custom function for the callback referenced above
 */
if (!function_exists('redux_my_custom_field')):
    function redux_my_custom_field($field, $value) {
        print_r($field);
        echo '<br/>';
        print_r($value);
    }
endif;

/**
  Custom function for the callback validation referenced above
 * */
if (!function_exists('redux_validate_callback_function')):
    function redux_validate_callback_function($field, $value, $existing_value) {
        $error = false;
        $value = 'just testing';

        /*
          do your validation

          if(something) {
            $value = $value;
          } elseif(something else) {
            $error = true;
            $value = $existing_value;
            $field['msg'] = 'your custom error message';
          }
         */

        $return['value'] = $value;
        if ($error == true) {
            $return['error'] = $field;
        }
        return $return;
    }
endif;
