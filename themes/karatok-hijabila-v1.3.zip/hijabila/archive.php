<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="cf">

						<div id="main" class="mf tlf t9 d9 lc cf" role="main">

							<div id="breadcrumbs" class="breadcrumbs clearfix"><?php karatok_breadcrumbs() ?></div>

							<div class="arsip-head cf">

								<?php if (is_category()) { ?>
									<h1 class="archive-title h2 fc">
										<span><?php _e( '', 'hijabila' ); ?> <?php single_cat_title(); ?></span>
									</h1>

								<?php } elseif (is_tag()) { ?>
									<h1 class="archive-title h2">
										<span><?php _e( 'Tags', 'hijabila' ); ?></span> <?php single_tag_title(); ?>
									</h1>

								<?php } elseif (is_author()) {
									global $post;
									$author_id = $post->post_author;
								?>
									<h1 class="archive-title h2">

										<span><?php _e( 'Posts By:', 'hijabila' ); ?></span> <?php the_author_meta('display_name', $author_id); ?>

									</h1>
								<?php } elseif (is_day()) { ?>
									<h1 class="archive-title h2">
										<span><?php _e( 'Daily Archive', 'hijabila' ); ?></span> <?php the_time('l, F j, Y'); ?>
									</h1>

								<?php } elseif (is_month()) { ?>
										<h1 class="archive-title h2">
											<span><?php _e( 'Monthly Archive', 'hijabila' ); ?></span> <?php the_time('F Y'); ?>
										</h1>

								<?php } elseif (is_year()) { ?>
										<h1 class="archive-title h2">
											<span><?php _e( 'Yearly Archive', 'hijabila' ); ?></span> <?php the_time('Y'); ?>
										</h1>
								<?php } ?>

								<div class="arsip-navi lc">
									<?php if ( function_exists( 'karatok_page_navi' ) ) { ?>
										<?php karatok_page_navi(); ?>
									<?php } else ?>
								</div>

							</div>

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
								<?php get_template_part( 'entry', 'content' ); ?>
							<?php endwhile; ?>

									<?php if ( function_exists( 'karatok_page_navi' ) ) { ?>
										<?php karatok_page_navi(); ?>
									<?php } else { ?>
										<nav class="wp-prev-next">
											<ul class="clearfix">
												<li class="prev-link"><?php next_posts_link( __( '&laquo; Older Entries', 'hijabila' )) ?></li>
												<li class="next-link"><?php previous_posts_link( __( 'Newer Entries &raquo;', 'hijabila' )) ?></li>
											</ul>
										</nav>
									<?php } ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
										<header class="article-header">
											<h1><?php _e( 'Oops, Post Not Found!', 'hijabila' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'hijabila' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php _e( 'This is the error message in the archive.php template.', 'hijabila' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>

						</div>

						<?php get_sidebar(); ?>

								</div>

			</div>

<?php get_footer(); ?>
