<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="cf">

						<div id="main" class="mf tlf t9 d9 lc cf" role="main">

							<div id="breadcrumbs" class="breadcrumbs cf"><?php karatok_breadcrumbs() ?></div>

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class('artikel-blog cf'); ?> role="article">

								<header class="article-header">

									<h1 class="single-title custom-post-type-title"><?php the_title(); ?></h1>
									<p class="byline vcard"><?php
										printf( __( '<time class="updated e-meta" datetime="%1$s"><i class="fa fa-clock-o"></i>%2$s</time> <span class="author e-meta"><i class="fa fa-user"></i>%3$s</span> <span class="e-meta"><i class="fa fa-folder"></i> %4$s</span>', 'hijabila' ), get_the_time( 'Y-m-j' ), get_the_time( __( 'F jS, Y', 'hijabila' ) ), karatok_get_the_author_posts_link(), get_the_term_list( $post->ID, 'custom_cat', ' ', ', ', '' ) );
									?></p>

								</header>

								<section class="entry-content clearfix">

									<?php the_content(); ?>

								</section>

								<footer class="article-footer cf">
									<p class="tags d6 fc"><?php echo get_the_term_list( get_the_ID(), 'custom_tag', '' . __( '', 'hijabila' ) . '', '' ) ?></p>
									<div class="blog-social-box mf tlf t6 d6 lc">
										<div class="blog-social-share cf">
											<p class="blog-social-share-text">share</p>
											<!-- AddThis Button BEGIN -->
											<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
												<a class="addthis_button_facebook"></a>
												<a class="addthis_button_twitter"></a>
												<a class="addthis_button_google_plusone_share"></a>
												<!--a class="addthis_button_pinterest_share"></a -->
												<!--a class="addthis_button_stumbleupon"></a -->
												<a class="addthis_button_linkedin"></a>
												<a class="addthis_button_email"></a>
											</div>
											<script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>
											<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-530f12991170d082"></script>
											<!-- AddThis Button END -->
										</div>
									</div>

								</footer>

								<?php karatok_sosial_media(); ?>

								<?php karatok_artikel_terkait_blog(); ?>

								<?php comments_template(); ?>

							</article>

							<?php endwhile; ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry clearfix">
										<header class="article-header">
											<h1><?php _e( 'Dooh, Tidak dapat ditemukan!', 'hijabila' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'Oh. Produk atau artikel yang anda cari tidak ditemukan, silahkan coba dengan kata kunci lainnya!', 'hijabila' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php _e( '', 'hijabila' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>

						</div>

						<?php get_sidebar('blog'); ?>

				</div>

			</div>

<?php get_footer(); ?>
