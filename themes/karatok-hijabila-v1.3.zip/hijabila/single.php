<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="cf">

					<div id="main" class="mf tlf t9 d9 lc cf" role="main">

						<div id="breadcrumbs" class="breadcrumbs cf"><?php karatok_breadcrumbs() ?></div>

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> itemscope itemtype="http://data-vocabulary.org/Product">

								<section class="produk-masuk entry-content df fc cf">

									<section class="entry-thumbmedium mf tl6 t4 d4 fc cf">
										<?php
										$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumbnail' );
										$large = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );
										$original = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
										$thumbcart = $thumbnail[0];
										echo '<div class="medium-product-thumb"><img id="single-ezoom" itemprop="image" src="'.$large[0].'" data-zoom-image="'.$original[0].'" alt="'.get_the_title().'"/></div>';

										$args = array(
											'post_type' => 'attachment',
											'numberposts' => -1,
											'post_status' => null,
											'post_parent' => $post->ID,
											'exclude'     => get_post_thumbnail_id()
										);

										$attachments = get_posts( $args );
										echo '<div id="single-egallery">';
										echo '<a href="#" class="elevatezoom-gallery active" data-image="'.$large[0].'" data-zoom-image="'.$original[0].'"><img src="'.$thumbnail[0].'" alt="'.get_the_title().'"/></a>';

										if ( $attachments ) {
											foreach ( $attachments as $attachment ) {
												$thumbnail = wp_get_attachment_image_src( $attachment->ID, 'thumbnail' );
												$large = wp_get_attachment_image_src( $attachment->ID, 'large' );
												$original = wp_get_attachment_image_src( $attachment->ID, 'full' );
												echo '<a href="#" class="elevatezoom-gallery" data-image="'.$large[0].'" data-zoom-image="'.$original[0].'"><img src="'.$thumbnail[0].'" alt="'.get_the_title().'"/></a>';
											}
										}
										echo '</div>';
										?>
									</section>

									<section class="entry-description mf tl6 t8 d8 lc">
										<h1 class="h4 entry-title-single" itemprop="name"><?php the_title(); ?></h1>
										<div class="product-shop mf tlf t6 d6 fc">
											<form class="jcart mf tlf tf df fc cf" method="post">
												<?php extract(karatok_post_meta()); ?>
												<div class="entry-price-box df fc cf" itemprop="offerDetails" itemscope itemtype="http://data-vocabulary.org/Offer">
													<div class="price-single">
														Rp <span itemprop="price"><?php karatok_price($hargadiskon, 1, 0); ?></span>
														<?php foreach( explode( ",", $ukuran ) as $k => $size ) :
															$size = explode( "-", trim( $size ) );
															$hargaku = $size[1];
															$asli = '';
															if( $diskon ) {
																$hargaku = $hargaku - ( $hargaku * $diskon / 100 );
																$asli = "<span class='asli'>".karatok_price($size[1], 0)."</span>";
															}
															if( $hargaku )
																$regone .= "<span class='hargaper-ukuran'>$asli".karatok_price($hargaku, 0)."<span class='ukuran'>{$size[0]}</span></span>";
															endforeach;
														?>
														<?php if( $regone ) : ?>
														<i title="Lihat detail harga" class="fa fa-angle-down"></i>
														<div class="hargaukuran-box tugelhide">
															<?php echo $regone; ?>
														</div>
														<?php endif; ?>
														<span itemprop="currency" content="IDR"></span>
														<?php if( $stok == 'ada' ) $instock = 'in_stock'; else $instock = 'out_of_stock'; ?>
														<span itemprop="availability" content="<?php echo $instock; ?>"></span>
													</div>
													<?php if( $diskon ) : ?>
													<div class="single-price-discount"><?php karatok_price($harganormal); ?></div>

													<div class="entry-discount-box">
														<div class="discount-single"><?php echo $diskon; ?>% off</div>
													</div>
													<?php endif; ?>

												</div>

												<div class="entry-product-detail-box mf tlf tf df fc cf">

													<div class="entry-stock-box cf">
														<span class="stock-box-box m5 tl5 t5 d5 fc">stock</span>
														<?php if( $stok == 'ada' ) : ?>
															<div class="single-stock ada m7 tl7 t7 d7 lc">Tersedia</div>
														<?php else : ?>
															<div class="single-stock habis m7 tl7 t7 d7 lc">Habis</div>
														<?php endif; ?>
													</div>

													<?php if( $kode ) : ?>
													<div class="hb-product-code cf">
														<span class="hb-box-left-detail m5 tl5 t5 d5 fc">Kode Produk</span>
														<span class="hb-box-right-detail">: <span itemprop="productID"><?php echo $kode; ?></span></span>
													</div>
													<?php endif; ?>

													<?php if( $ukuran ) : ?>
													<div class="hb-product-size cf">
														<span class="hb-box-left-detail m5 tl5 t5 d5 fc">Pilih Ukuran</span>
														<span class="hb-size-box">: <?php foreach( explode( ",", $ukuran ) as $k => $size ) :
																$size = explode( "-", trim( $size ) ); $hargaku = $size[1];
																if( $diskon ) {
																	$hargaku = $size[1] - ( $size[1] * $diskon / 100 );
																}
																echo "<input data-hargaku=\"$hargaku\" type=\"radio\" id=\"size$k\" name=\"my-item-size\" value=\"{$size[0]}\" ".checked($k, 0, 0)."><label for=\"size$k\">{$size[0]}</label>";
															endforeach; ?>
														</span>
													</div>
													<?php endif; ?>

													<?php if( $warna ) : ?>
													<div class="hb-product-color cf">
														<span class="hb-box-left-detail m5 tl5 t5 d5 fc">Pilih Warna</span>
														<span class="hb-color-box">: <?php foreach( explode( ",", $warna ) as $k => $warni ) :
																if( $warni = trim( $warni ) ) echo "<input type=\"radio\" id=\"warna$k\" name=\"my-item-color\" value=\"$warni\" ".checked($k, 0, 0)."><label for=\"warna$k\" class=\"$warni\" title=\"Warna $warni\">&nbsp;</label>";
															endforeach; ?></span>
													</div>
													<?php endif; ?>
												</div>

												<input type="hidden" name="jcartToken" value="<?php echo $_SESSION['jcartToken'];?>" />
												<input type="hidden" name="my-item-id" value="<?php echo $kode ? $kode : get_the_ID(); ?>" />
												<input type="hidden" name="my-item-name" value="<?php the_title(); ?>" />
												<input type="hidden" name="my-item-price" value="<?php echo $hargadiskon; ?>" />
												<input type="hidden" name="my-item-url" value="<?php the_permalink(); ?>" />
												<input type="hidden" name="my-item-thumb" value="<?php echo $thumbcart; ?> " />
												<input type="hidden" name="my-item-weight" value="<?php echo $berat; ?>" />
												<input type="hidden" name="my-item-qty" value="1"/>
												<?php if( $karatok['buttontexton'] ) : ?>
												<input type="submit" name="my-add-button" value="<?php echo $karatok['buttontext']; ?>" class="hp-cart-button addtocart mf tlf tf df cf" <?php disabled( $stok, 'habis' ); ?> />
												<?php endif; ?>
											</form>

											<?php if( $karatok['tombolviasms'] ) : ?>
											<div class="via-sms mf tlf tf df cf">
												<a href="#pesanviasms" class="pesanviasms">Pemesanan via SMS</a>
											</div>
											<?php endif; ?>

											<div class="blog-social-box produk-social df cf">
												<div class="blog-social-share cf">
													<p class="blog-social-share-text">share</p>
													<!-- AddThis Button BEGIN -->
													<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
														<a class="addthis_button_facebook"></a>
														<a class="addthis_button_twitter"></a>
														<a class="addthis_button_google_plusone_share"></a>
														<a class="addthis_button_pinterest_share"></a>
														<!--a class="addthis_button_stumbleupon"></a-->
														<!--a class="addthis_button_linkedin"></a-->
														<a class="addthis_button_email"></a>
													</div>
													<script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>
													<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-530f12991170d082"></script>
													<!-- AddThis Button END -->
												</div>
											</div>

										</div>

										<div class="product-description mf tlf t6 d6 lc">
											<h5 class="product-description-title"><span>Deskripsi Produk</span></h5>
												<div class="produk-box-detail">

													<div class="hb-product-code cf">
														<span class="hb-box-left-detail m5 tl5 t5 d5 fc">Rating</span>
														<span class="hb-box-right-detail">:
															<?php for( $i=1; $i<=floor($rating); $i++ ) : ?>
															<i class="fa fa-star"></i>
															<?php endfor; ?>
															<?php if( $rating != floor($rating) ) : ?>
															<i class="fa fa-star-half-o"></i>
															<?php endif; ?>
															<?php for( $i=ceil($rating); $i<5; $i++ ) : ?>
															<i class="fa fa-star-o"></i>
															<?php endfor; ?>
															<span itemprop="review" itemscope itemtype="http://data-vocabulary.org/Review-aggregate">
																<span itemprop="rating"><?php echo $rating ? $rating : 0; ?></span>/5<span itemprop="count" content="99"></span>
															</span>
														</span>
													</div>
													<?php if( $berat ) : ?>
													<div class="hb-product-weight cf">
														<span class="hb-box-left-detail m5 tl5 t5 d5 fc">Berat</span>
														<span class="hb-box-right-detail">: <?php echo $berat; ?> KG</span>
													</div>
													<?php endif; ?>

													<div class="hb-product-category cf">
														<span class="hb-box-left-detail m5 tl5 t5 d5 fc">Kategori</span>
														<span class="hb-box-right-detail">:
														<?php
															$category = get_the_category();
															if($category[0]){
															echo '<span class="hb-product-category"><a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a></span>';
														 } ?>
														 </span>
													</div>
												</div>
											<div itemprop="description"><?php the_content(); ?></div>
											<?php the_tags( '<p class="tags"><span class="tags-title">' . __( 'Tags:', 'hijabila' ) . '</span> ', ', ', '</p>' ); ?>
										</div>

									</section>

								</section>

								<?php karatok_pernah_dilihat() ?>

								<?php karatok_tabs_related(); ?>

								<?php //comments_template(); ?>

							</article>

						<?php endwhile; ?>

						<?php else : ?>

							<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'Maaf, Produk tidak ditemukan!', 'hijabila' ); ?></h1>
									</header>
									<section class="entry-content">
										<p><?php _e( 'Oh. Produk tidak ditemukan. Silahkan cari dengan kata kunci lainnya.', 'hijabila' ); ?></p>
									</section>
									<footer class="article-footer">
											<p><?php _e( 'ERROR!', 'hijabila' ); ?></p>
									</footer>
							</article>

						<?php endif; ?>

					</div>

					<?php get_sidebar(); ?>

				</div>

			</div>

<?php get_footer(); ?>
