<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="cf">

					<div id="main" class="mf tlf t9 d9 lc cf" role="main">

						<div id="breadcrumbs" class="breadcrumbs cf"><?php karatok_breadcrumbs() ?></div>

						<h1 class="archive-title h4"><span><?php _e( 'Hasil pencarian:', 'hijabila' ); ?></span> <?php echo esc_attr(get_search_query()); ?></h1>

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<?php get_template_part( 'entry', 'content' ); ?>
						<?php endwhile; ?>

								<?php if (function_exists('karatok_page_navi')) { ?>
										<?php karatok_page_navi(); ?>
								<?php } else { ?>
										<nav class="wp-prev-next">
												<ul class="clearfix">
													<li class="prev-link"><?php next_posts_link( __( '&laquo; Older Entries', 'hijabila' )) ?></li>
													<li class="next-link"><?php previous_posts_link( __( 'Newer Entries &raquo;', 'hijabila' )) ?></li>
												</ul>
										</nav>
								<?php } ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
										<header class="article-header">
											<h1><?php _e( 'Maaf, Tidak ada hasil.', 'hijabila' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'Silahkan coba mencari lagi dengan kata kunci global.', 'hijabila' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php //_e( 'This is the error message in the search.php template.', 'hijabila' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>

						</div>

							<?php get_sidebar(); ?>

					</div>

			</div>

<?php get_footer(); ?>
